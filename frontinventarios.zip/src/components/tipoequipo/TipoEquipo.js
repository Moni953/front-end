import React from 'react'

export default function TipoEquipo() {
  return (
    <div className='container'>TipoEquipo</div>
  )
}
