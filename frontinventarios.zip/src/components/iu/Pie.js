import React from 'react'

export default function Pie() {
  return (
    <div>Pie</div>
  )
}
