import React from 'react'

export default function Marca() {
  return (
    <div className='container'>Marca</div>
  )
}
