import MainRouter from "./routes/MainRouter";

function App() {
  return (
    <MainRouter />
  );
}

export default App;
